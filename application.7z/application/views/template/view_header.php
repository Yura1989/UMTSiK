<!doctype html>
<!--<html class="fixed sidebar-left-collapsed">-->
<html class="fixed">
<head>
    <meta charset="UTF-8">
    <title>info_МТР</title>
    <meta name="programmer Dudin Uiriy">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="<?=base_url();?>assets/vendor/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="<?=base_url();?>assets/vendor/font-awesome/css/font-awesome.css" />
    <link rel="stylesheet" href="<?=base_url();?>assets/vendor/magnific-popup/magnific-popup.css" />
    <link rel="shortcut icon" href="<?=base_url();?>assets/vendor/favicon.png" type="image/png">

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="<?=base_url();?>assets/vendor/select2/select2.css" />
    <link rel="stylesheet" href="<?=base_url();?>assets/vendor/jquery-datatables-bs3/assets/css/datatables.css" />

    <!-- Theme CSS Menu-->
    <link rel="stylesheet" href="<?=base_url();?>assets/vendor/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="<?=base_url();?>assets/vendor/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="<?=base_url();?>assets/vendor/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="<?=base_url();?>assets/vendor/modernizr/modernizr.js"></script>
    <script src="<?=base_url();?>assets/vendor/jquery-3.3.1.min.js"></script>

</head>

